1. Installation:
-----------------------------
Theme Packages
 - doris1-rxx.zip
 - doris2-rxx.zip
	
Chooes a theme package and upload to Shopify store.


2. Installation & User Guide: 
-----------------------------
Go to "Documentation" folder and open index.html in your web browser for detail instruction.
